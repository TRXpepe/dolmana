from flask import Flask, render_template, jsonify, make_response
import requests
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
from functools import wraps

app = Flask(__name__)

def nocache(view):
    @wraps(view)
    def no_cache(*args, **kwargs):
        response = make_response(view(*args, **kwargs))
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '-1'
        return response
    return no_cache

def get_upbit_price(symbol):
    try:
        url = f"https://api.upbit.com/v1/ticker?markets=KRW-{symbol}"
        response = requests.get(url, timeout=5)
        data = response.json()
        if data:
            return float(data[0]['trade_price'])
    except Exception as e:
        print(f"Error fetching Upbit price: {e}")
        return None

def get_bitkub_price(symbol):
    try:
        # Bitkub API endpoint for getting last price
        # Convert symbol to Bitkub format
        symbol_mapping = {
            'BTC': 'THB_BTC',
            'ETH': 'THB_ETH',
            'XRP': 'THB_XRP',
            'SOL': 'THB_SOL',
            'DOGE': 'THB_DOGE',
            'ADA': 'THB_ADA',
            'USDT': 'THB_USDT'  # USDT 추가
        }
        
        bitkub_symbol = symbol_mapping.get(symbol)
        if not bitkub_symbol:
            return None
            
        url = "https://api.bitkub.com/api/market/ticker"
        response = requests.get(url, timeout=5)
        data = response.json()
        
        if data and bitkub_symbol in data:
            return float(data[bitkub_symbol]['last'])
        return None
    except Exception as e:
        print(f"Error fetching Bitkub price: {e}")
        return None

def get_exchange_rate():
    try:
        # 네이버 금융 환율 페이지
        url = "https://finance.naver.com/marketindex/exchangeDetail.naver?marketindexCd=FX_THBKRW"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 현재 환율 추출 (수정된 선택자)
        rate_element = soup.select_one('#content > div.spot_area > div.today > p.no_today > em')
        if not rate_element:
            # 백업 선택자 시도
            rate_element = soup.select_one('.no_today em')
            
        if rate_element:
            # 숫자만 추출
            rate_text = ''.join(filter(lambda x: x.isdigit() or x == '.', rate_element.text.strip()))
            thb_to_krw = float(rate_text)
            print(f"Successfully fetched exchange rate: {thb_to_krw} KRW/THB")  # 디버깅용 로그
            return {
                'thb_to_krw': thb_to_krw,
                'krw_to_thb': round(1 / thb_to_krw, 4),
                'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            print("Could not find exchange rate element")
            print("Page content:", soup.select('.spot_area'))  # 디버깅용 로그
    except Exception as e:
        print(f"Error fetching exchange rate: {e}")
        if 'response' in locals():
            print(f"Response status: {response.status_code}")
            print(f"Response headers: {response.headers}")
            print("Response content preview:")
            print(response.text[:1000])  # 처음 1000자 출력
    
    # 에러 발생시 기본값 반환 (2024년 4월 기준 실제 환율에 가까운 값)
    return {
        'thb_to_krw': 36.82,
        'krw_to_thb': round(1 / 36.82, 4),
        'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

def convert_thb_to_krw(thb_price):
    exchange_rate = get_exchange_rate()
    return thb_price * exchange_rate['thb_to_krw'] if thb_price else None

def calculate_premium(kr_price, thb_price):
    if not kr_price or not thb_price:
        return 0
    # THB를 KRW로 변환
    thb_price_in_krw = convert_thb_to_krw(thb_price)
    if not thb_price_in_krw:
        return 0
    premium = ((kr_price / thb_price_in_krw) - 1) * 100
    return round(premium, 2)

@app.route('/')
@nocache
def index():
    # 주요 암호화폐 심볼 (USDT 추가)
    coins = ['BTC', 'ETH', 'XRP', 'SOL', 'DOGE', 'ADA', 'USDT']
    
    market_data = []
    for coin in coins:
        upbit_price = get_upbit_price(coin)
        bitkub_price = get_bitkub_price(coin)
        bitkub_price_krw = convert_thb_to_krw(bitkub_price) if bitkub_price else None
        premium = calculate_premium(upbit_price, bitkub_price) if bitkub_price else 0

        market_data.append({
            'symbol': coin,
            'upbit_price': upbit_price,
            'bitkub_price': bitkub_price,
            'bitkub_price_krw': bitkub_price_krw,
            'premium': premium
        })

    exchange_rate = get_exchange_rate()
    return render_template('index.html', 
                         market_data=market_data, 
                         exchange_rate=exchange_rate,
                         last_update=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

@app.route('/update_prices')
@nocache
def update_prices():
    # 주요 암호화폐 심볼 (USDT 추가)
    coins = ['BTC', 'ETH', 'XRP', 'SOL', 'DOGE', 'ADA', 'USDT']
    
    market_data = []
    exchange_rate = get_exchange_rate()
    
    for coin in coins:
        upbit_price = get_upbit_price(coin)
        bitkub_price = get_bitkub_price(coin)
        bitkub_price_krw = convert_thb_to_krw(bitkub_price) if bitkub_price else None
        premium = calculate_premium(upbit_price, bitkub_price) if bitkub_price else 0

        market_data.append({
            'symbol': coin,
            'upbit_price': upbit_price,
            'bitkub_price': bitkub_price,
            'bitkub_price_krw': bitkub_price_krw,
            'premium': premium
        })

    return jsonify({
        'market_data': market_data,
        'exchange_rate': exchange_rate
    })

if __name__ == '__main__':
    app.run(debug=True) 