import json
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os

def handler(event, context):
    """Netlify Function handler"""
    
    # CORS 헤더
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }
    
    try:
        # API 경로에 따른 처리
        path = event.get('path', '').rstrip('/')
        
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 204,
                'headers': headers,
                'body': ''
            }
        
        if path == '/.netlify/functions/app' or path == '/':
            # 메인 페이지 요청
            market_data = get_market_data()
            exchange_rate = get_exchange_rate()
            
            # HTML 파일 읽기
            current_dir = os.path.dirname(os.path.abspath(__file__))
            template_path = os.path.join(current_dir, 'templates', 'index.html')
            
            try:
                with open(template_path, 'r', encoding='utf-8') as f:
                    html = f.read()
            except FileNotFoundError:
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': f'Template not found at {template_path}'})
                }
            
            # 데이터 삽입
            html = html.replace('{{market_data}}', json.dumps(market_data))
            html = html.replace('{{exchange_rate}}', json.dumps(exchange_rate))
            html = html.replace('{{last_update}}', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            
            headers['Content-Type'] = 'text/html'
            return {
                'statusCode': 200,
                'headers': headers,
                'body': html
            }
            
        elif path == '/.netlify/functions/app/update_prices':
            # 가격 업데이트 API
            market_data = get_market_data()
            exchange_rate = get_exchange_rate()
            
            headers['Content-Type'] = 'application/json'
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'market_data': market_data,
                    'exchange_rate': exchange_rate
                })
            }
            
        else:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': 'Not Found'})
            }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }

def get_market_data():
    coins = ['BTC', 'ETH', 'XRP', 'SOL', 'DOGE', 'ADA', 'USDT']
    market_data = []
    
    for coin in coins:
        upbit_price = get_upbit_price(coin)
        bitkub_price = get_bitkub_price(coin)
        bitkub_price_krw = convert_thb_to_krw(bitkub_price) if bitkub_price else None
        premium = calculate_premium(upbit_price, bitkub_price) if bitkub_price else 0
        
        market_data.append({
            'symbol': coin,
            'upbit_price': upbit_price,
            'bitkub_price': bitkub_price,
            'bitkub_price_krw': bitkub_price_krw,
            'premium': premium
        })
    
    return market_data

def get_upbit_price(symbol):
    try:
        url = f"https://api.upbit.com/v1/ticker?markets=KRW-{symbol}"
        response = requests.get(url, timeout=5)
        data = response.json()
        if data:
            return float(data[0]['trade_price'])
    except Exception as e:
        print(f"Error fetching Upbit price: {e}")
        return None

def get_bitkub_price(symbol):
    try:
        symbol_mapping = {
            'BTC': 'THB_BTC',
            'ETH': 'THB_ETH',
            'XRP': 'THB_XRP',
            'SOL': 'THB_SOL',
            'DOGE': 'THB_DOGE',
            'ADA': 'THB_ADA',
            'USDT': 'THB_USDT'
        }
        
        bitkub_symbol = symbol_mapping.get(symbol)
        if not bitkub_symbol:
            return None
            
        url = "https://api.bitkub.com/api/market/ticker"
        response = requests.get(url, timeout=5)
        data = response.json()
        
        if data and bitkub_symbol in data:
            return float(data[bitkub_symbol]['last'])
        return None
    except Exception as e:
        print(f"Error fetching Bitkub price: {e}")
        return None

def get_exchange_rate():
    try:
        url = "https://finance.naver.com/marketindex/exchangeDetail.naver?marketindexCd=FX_THBKRW"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        rate_element = soup.select_one('#content > div.spot_area > div.today > p.no_today > em')
        if not rate_element:
            rate_element = soup.select_one('.no_today em')
            
        if rate_element:
            rate_text = ''.join(filter(lambda x: x.isdigit() or x == '.', rate_element.text.strip()))
            thb_to_krw = float(rate_text)
            return {
                'thb_to_krw': thb_to_krw,
                'krw_to_thb': round(1 / thb_to_krw, 4),
                'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
    except Exception as e:
        print(f"Error fetching exchange rate: {e}")
    
    return {
        'thb_to_krw': 36.82,
        'krw_to_thb': round(1 / 36.82, 4),
        'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

def convert_thb_to_krw(thb_price):
    if not thb_price:
        return None
    exchange_rate = get_exchange_rate()
    return thb_price * exchange_rate['thb_to_krw']

def calculate_premium(kr_price, thb_price):
    if not kr_price or not thb_price:
        return 0
    thb_price_in_krw = convert_thb_to_krw(thb_price)
    if not thb_price_in_krw:
        return 0
    premium = ((kr_price / thb_price_in_krw) - 1) * 100
    return round(premium, 2) 